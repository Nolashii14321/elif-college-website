// Backend/list-users.js
// Script to list all users in the database

const mysql = require('mysql2');
require('dotenv').config();

const db = mysql.createPool({
    connectionLimit: 10,
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: (process.env.DB_PASSWORD || 'root').replace(/^['"]|['"]$/g, ''),
    database: process.env.DB_NAME || 'school_db'
});

console.log('\n=== All Users in Database ===\n');

const sql = `SELECT id, name, email, role FROM users ORDER BY id`;

db.query(sql, (err, results) => {
    if (err) {
        console.error('❌ Error:', err.message);
        process.exit(1);
    }
    
    if (results.length === 0) {
        console.log('No users found in the database.\n');
        process.exit(0);
    }
    
    console.log('Total users:', results.length);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    results.forEach((user, index) => {
        console.log(`${index + 1}. ID: ${user.id}`);
        console.log(`   Name: ${user.name}`);
        console.log(`   Email: ${user.email}`);
        console.log(`   Role: ${user.role}`);
        console.log('');
    });
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
    process.exit(0);
});

