const mysql = require('mysql2');
require('dotenv').config();

console.log('Testing database connection...');
console.log('Host:', process.env.DB_HOST);
console.log('User:', process.env.DB_USER);
console.log('Password:', process.env.DB_PASSWORD);
console.log('Database:', process.env.DB_NAME);

// Try with root as password
const db = mysql.createPool({
    connectionLimit: 10,
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: 'root', // Try root as password
    database: process.env.DB_NAME || 'school_db'
});

db.getConnection((err, connection) => {
    if (err) {
        console.error('Connection failed:', err.message);
        console.error('Error code:', err.code);
        
        // Try without password
        console.log('\nTrying without password...');
        const dbNoPass = mysql.createPool({
            connectionLimit: 10,
            host: process.env.DB_HOST || 'localhost',
            user: process.env.DB_USER || 'root',
            password: '', // No password
            database: process.env.DB_NAME || 'school_db'
        });
        
        dbNoPass.getConnection((err2, connection2) => {
            if (err2) {
                console.error('Connection without password also failed:', err2.message);
            } else {
                console.log('✅ Database connected successfully without password!');
                connection2.release();
            }
            process.exit();
        });
    } else {
        console.log('✅ Database connected successfully with root password!');
        connection.release();
        process.exit();
    }
});
