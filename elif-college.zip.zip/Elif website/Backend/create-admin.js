const mysql = require('mysql2');
const bcrypt = require('bcrypt');
require('dotenv').config();

console.log('Creating default admin user...');

const db = mysql.createPool({
    connectionLimit: 10,
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: (process.env.DB_PASSWORD || 'root').replace(/^['"]|['"]$/g, ''),
    database: process.env.DB_NAME || 'school_db'
});

async function createAdminUser() {
    try {
        // First, check if admin user already exists
        const checkSql = `SELECT * FROM users WHERE email = ?`;
        
        db.query(checkSql, ['admin'], async (err, results) => {
            if (err) {
                console.error('Error checking for admin user:', err.message);
                return;
            }
            
            if (results.length > 0) {
                console.log('Admin user already exists!');
                console.log('Email:', results[0].email);
                console.log('Role:', results[0].role);
                process.exit();
            }
            
            // Create the admin user
            console.log('Creating admin user...');
            const hashedPassword = await bcrypt.hash('password123', 10);
            
            const insertSql = `INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)`;
            
            db.query(insertSql, ['Admin User', 'admin', hashedPassword, 'Admin'], (insertErr, result) => {
                if (insertErr) {
                    console.error('Error creating admin user:', insertErr.message);
                    return;
                }
                
                console.log('✅ Admin user created successfully!');
                console.log('Email: admin');
                console.log('Password: password123');
                console.log('Role: Admin');
                process.exit();
            });
        });
        
    } catch (error) {
        console.error('Error:', error.message);
        process.exit();
    }
}

createAdminUser();

