// test-server.js
const express = require('express');
const path = require('path');
const app = express();

const projectRoot = path.join(__dirname, '..');
console.log(`Serving static files from this directory: ${projectRoot}`);

app.use(express.static(projectRoot));

app.listen(3000, () => {
    console.log('Test server is running on http://localhost:3000');
    console.log('Try accessing http://localhost:3000/HTML/parent-dashboard.html');
});