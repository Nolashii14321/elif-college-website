// Backend/create-admin-user.js
// Script to create a new admin user with custom details

const mysql = require('mysql2');
const bcrypt = require('bcrypt');
require('dotenv').config();
const readline = require('readline');

const db = mysql.createPool({
    connectionLimit: 10,
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: (process.env.DB_PASSWORD || 'root').replace(/^['"]|['"]$/g, ''),
    database: process.env.DB_NAME || 'school_db'
});

// Create readline interface for user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

function askQuestion(question) {
    return new Promise((resolve) => {
        rl.question(question, (answer) => {
            resolve(answer);
        });
    });
}

async function createAdminUser() {
    try {
        console.log('\n=== Create New Admin User ===\n');
        
        // Get user details from command line arguments or prompt
        let name, email, password, role;
        
        if (process.argv[2] && process.argv[3] && process.argv[4]) {
            // If arguments provided: node create-admin-user.js "Name" "email@example.com" "password"
            name = process.argv[2];
            email = process.argv[3];
            password = process.argv[4];
            role = process.argv[5] || 'Admin';
        } else {
            // Interactive mode
            name = await askQuestion('Enter admin name: ');
            email = await askQuestion('Enter admin email: ');
            password = await askQuestion('Enter admin password: ');
            role = await askQuestion('Enter role (Admin/Teacher/Student/Parent) [Admin]: ') || 'Admin';
        }
        
        // Validate inputs
        if (!name || !email || !password) {
            console.error('❌ Error: Name, email, and password are required!');
            rl.close();
            process.exit(1);
        }
        
        // Check if user already exists
        const checkSql = `SELECT * FROM users WHERE email = ?`;
        
        db.query(checkSql, [email], async (err, results) => {
            if (err) {
                console.error('❌ Error checking for user:', err.message);
                rl.close();
                process.exit(1);
            }
            
            if (results.length > 0) {
                console.log('\n⚠️  User with this email already exists!');
                console.log('Email:', results[0].email);
                console.log('Name:', results[0].name);
                console.log('Role:', results[0].role);
                rl.close();
                process.exit(0);
            }
            
            // Create the admin user
            console.log('\nCreating admin user...');
            const hashedPassword = await bcrypt.hash(password, 10);
            
            const insertSql = `INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)`;
            
            db.query(insertSql, [name, email, hashedPassword, role], (insertErr, result) => {
                if (insertErr) {
                    console.error('❌ Error creating admin user:', insertErr.message);
                    rl.close();
                    process.exit(1);
                }
                
                console.log('\n✅ Admin user created successfully!');
                console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
                console.log('Name:', name);
                console.log('Email:', email);
                console.log('Password:', password);
                console.log('Role:', role);
                console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
                rl.close();
                process.exit(0);
            });
        });
        
    } catch (error) {
        console.error('❌ Error:', error.message);
        rl.close();
        process.exit(1);
    }
}

createAdminUser();

